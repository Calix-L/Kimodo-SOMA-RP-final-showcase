# SPDX-License-Identifier: GPL-3.0-or-later
"""Chinese prompt UI layered on top of Proscenium's existing workflow."""

from __future__ import annotations

from typing import ClassVar

import bpy
from bpy.props import PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup

from . import properties
from .translation import TranslationError, contains_chinese, translate_zh_to_en


ORIGINAL_MODEL_ID = "Kimodo-SOMA-RP-v1.1-original"
FINETUNED_MODEL_ID = "Kimodo-SOMA-RP-v1.1-finetuned"
FINETUNED_OF_MODEL_ID = "Kimodo-SOMA-RP-v1.1-finetuned-of"
MIX_K03_MODEL_ID = "Kimodo-SOMA-RP-v1.1-finetuned-mix-k0.3"
MIX_K05_MODEL_ID = "Kimodo-SOMA-RP-v1.1-finetuned-mix-k0.5"
MIX_K07_MODEL_ID = "Kimodo-SOMA-RP-v1.1-finetuned-mix-k0.7"
MIX_K09_MODEL_ID = "Kimodo-SOMA-RP-v1.1-finetuned-mix-k0.9"

MODEL_CHOICES = (
    (ORIGINAL_MODEL_ID, "原版 Kimodo"),
    (FINETUNED_MODEL_ID, "微调 checkpoint"),
    (FINETUNED_OF_MODEL_ID, "微调 OF"),
    (MIX_K03_MODEL_ID, "Mix k0.3"),
    (MIX_K05_MODEL_ID, "Mix k0.5"),
    (MIX_K07_MODEL_ID, "Mix k0.7"),
    (MIX_K09_MODEL_ID, "Mix k0.9"),
)


def _addon_prefs(context):
    try:
        return context.preferences.addons[__package__].preferences
    except (AttributeError, KeyError):
        return None


def _active_prompt_block(settings, scene):
    """Return the active block, creating one over the scene range if needed."""
    if len(settings.prompt_blocks) == 0:
        block = settings.prompt_blocks.add()
        block.frame_start = int(scene.frame_start)
        block.frame_end = int(scene.frame_end)
        block.enabled = True
        settings.active_block_index = 0
        return block

    index = max(0, min(int(settings.active_block_index), len(settings.prompt_blocks) - 1))
    settings.active_block_index = index
    return settings.prompt_blocks[index]


def _translate_into_active_block(context) -> str:
    assistant = context.scene.kimodo_zh
    source_text = (assistant.chinese_prompt or "").strip()
    if not source_text:
        raise TranslationError("请输入动作描述")

    if contains_chinese(source_text):
        prefs = _addon_prefs(context)
        api_key = getattr(prefs, "google_translate_api_key", "") if prefs else ""
        english = translate_zh_to_en(source_text, api_key)
    else:
        # English remains a first-class input and never requires an API call.
        english = source_text

    settings = context.scene.proscenium
    block = _active_prompt_block(settings, context.scene)
    block.prompt = english
    assistant.english_preview = english
    assistant.status_message = "已写入当前 Proscenium 提示块"

    armature = properties._live_armature(settings.target_armature)
    if armature is not None:
        properties.save_blocks_to_armature(armature, settings)
    return english


class KimodoZhSettings(PropertyGroup):
    chinese_prompt: StringProperty(
        name="中文动作描述",
        description="输入中文；如果输入已经是英文，将直接写入提示块而不调用翻译 API",
        default="",
    )
    english_preview: StringProperty(
        name="英文 Prompt",
        description="发送给 Kimodo 的英文动作提示，可在翻译后直接修改",
        default="",
    )
    status_message: StringProperty(
        name="状态",
        default="",
        options={"SKIP_SAVE"},
    )


class KIMODO_ZH_OT_translate(Operator):
    bl_idname = "kimodo_zh.translate"
    bl_label = "翻译并写入提示块"
    bl_description = "将中文翻译成英文并写入当前 Proscenium 时间段"
    bl_options: ClassVar[set[str]] = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            english = _translate_into_active_block(context)
        except TranslationError as exc:
            context.scene.kimodo_zh.status_message = str(exc)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, f"英文 Prompt：{english}")
        return {"FINISHED"}


class KIMODO_ZH_OT_apply_english(Operator):
    bl_idname = "kimodo_zh.apply_english"
    bl_label = "写入修改后的英文"
    bl_description = "把英文预览框的内容写回当前 Proscenium 提示块"
    bl_options: ClassVar[set[str]] = {"REGISTER", "UNDO"}

    def execute(self, context):
        assistant = context.scene.kimodo_zh
        english = (assistant.english_preview or "").strip()
        if not english:
            self.report({"ERROR"}, "英文 Prompt 不能为空")
            return {"CANCELLED"}
        settings = context.scene.proscenium
        block = _active_prompt_block(settings, context.scene)
        block.prompt = english
        assistant.status_message = "已写入当前 Proscenium 提示块"
        armature = properties._live_armature(settings.target_armature)
        if armature is not None:
            properties.save_blocks_to_armature(armature, settings)
        return {"FINISHED"}


class KIMODO_ZH_OT_use_model(Operator):
    bl_idname = "kimodo_zh.use_model"
    bl_label = "切换 Kimodo 对比模型"
    bl_description = "在同一服务内切换模型；保留提示、Seed、帧范围和骨骼"

    model_id: StringProperty(options={"SKIP_SAVE"})

    def execute(self, context):
        labels = dict(MODEL_CHOICES)
        label = labels.get(self.model_id)
        if label is None:
            self.report({"ERROR"}, "未知的 Kimodo 对比模型")
            return {"CANCELLED"}

        from . import mmcp_client

        available = {
            model.get("id")
            for model in (mmcp_client.cached_capabilities() or {}).get("models", [])
        }
        if self.model_id not in available:
            self.report({"ERROR"}, "当前服务没有该模型，请先在插件设置中重新连接")
            return {"CANCELLED"}

        context.scene.proscenium.model_id = self.model_id
        context.scene.kimodo_zh.status_message = f"当前模型：{label}"
        self.report({"INFO"}, f"已切换到{label}")
        return {"FINISHED"}


class KIMODO_ZH_OT_translate_and_generate(Operator):
    bl_idname = "kimodo_zh.translate_and_generate"
    bl_label = "翻译并生成动作"
    bl_description = "翻译、写入当前提示块，然后调用 Proscenium 原有生成流程"
    bl_options: ClassVar[set[str]] = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            _translate_into_active_block(context)
        except TranslationError as exc:
            context.scene.kimodo_zh.status_message = str(exc)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return bpy.ops.proscenium.generate("INVOKE_DEFAULT")


class KIMODO_ZH_PT_assistant(Panel):
    bl_label = "Kimodo 中文助手"
    bl_idname = "KIMODO_ZH_PT_assistant"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Proscenium"
    bl_parent_id = "PROSCENIUM_PT_main"

    def draw(self, context):
        layout = self.layout
        assistant = context.scene.kimodo_zh
        settings = context.scene.proscenium

        from . import mmcp_client

        available_models = {
            model.get("id")
            for model in (mmcp_client.cached_capabilities() or {}).get("models", [])
        }
        compare = layout.box()
        compare.label(text="同一服务模型对比（保持 Prompt 与 Seed）", icon="UV_SYNC_SELECT")
        grid = compare.grid_flow(
            row_major=True, columns=2, even_columns=True, align=True
        )
        grid.enabled = not settings.is_generating and bool(available_models)
        for model_id, label in MODEL_CHOICES:
            op = grid.operator(
                "kimodo_zh.use_model",
                text=label,
                icon="CHECKMARK" if settings.model_id == model_id else "NONE",
            )
            op.model_id = model_id
        missing = {model_id for model_id, _label in MODEL_CHOICES} - available_models
        if missing:
            compare.label(text="请连接包含全部七个模型的 Kimodo 服务", icon="INFO")

        layout.prop(assistant, "chinese_prompt", text="中文")
        row = layout.row()
        row.operator("kimodo_zh.translate", icon="WORLD", text="翻译")

        layout.prop(assistant, "english_preview", text="English")
        layout.operator("kimodo_zh.apply_english", icon="CHECKMARK")

        if len(settings.prompt_blocks) > 0:
            index = max(0, min(settings.active_block_index, len(settings.prompt_blocks) - 1))
            block = settings.prompt_blocks[index]
            layout.label(
                text=f"当前提示块：{index + 1}（{block.frame_start}–{block.frame_end} 帧）",
                icon="NLA",
            )
        else:
            layout.label(text="翻译时会自动创建一个提示块", icon="INFO")

        row = layout.row()
        row.scale_y = 1.3
        row.enabled = not settings.is_generating
        row.operator("kimodo_zh.translate_and_generate", icon="PLAY")

        if assistant.status_message:
            layout.label(text=assistant.status_message, icon="INFO")


_classes = (
    KimodoZhSettings,
    KIMODO_ZH_OT_translate,
    KIMODO_ZH_OT_apply_english,
    KIMODO_ZH_OT_use_model,
    KIMODO_ZH_OT_translate_and_generate,
    KIMODO_ZH_PT_assistant,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.kimodo_zh = PointerProperty(type=KimodoZhSettings)


def unregister():
    del bpy.types.Scene.kimodo_zh
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
