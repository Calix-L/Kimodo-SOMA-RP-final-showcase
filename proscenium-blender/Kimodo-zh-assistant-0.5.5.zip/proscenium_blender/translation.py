# SPDX-License-Identifier: GPL-3.0-or-later
"""Small, dependency-free translation client for Kimodo-zh-assistant."""

from __future__ import annotations

import html
import json
from collections.abc import Callable
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

GOOGLE_TRANSLATE_URL = "https://translation.googleapis.com/language/translate/v2"


class TranslationError(RuntimeError):
    """A user-facing translation failure that never contains the API key."""


def contains_chinese(text: str) -> bool:
    """Return whether *text* contains a CJK Unified Ideograph."""
    return any(
        "\u3400" <= char <= "\u4dbf"
        or "\u4e00" <= char <= "\u9fff"
        or "\uf900" <= char <= "\ufaff"
        for char in text
    )


def translate_zh_to_en(
    text: str,
    api_key: str,
    *,
    timeout: float = 15.0,
    opener: Callable[..., Any] = urlopen,
) -> str:
    """Translate plain Chinese text to English with Google Cloud Basic v2."""
    source_text = (text or "").strip()
    if not source_text:
        raise TranslationError("请输入中文动作描述")
    if not (api_key or "").strip():
        raise TranslationError("请先在插件偏好设置中填写 Google Cloud Translation API Key")

    request_body = json.dumps(
        {
            "q": source_text,
            "source": "zh-CN",
            "target": "en",
            "format": "text",
        },
        ensure_ascii=False,
    ).encode("utf-8")
    endpoint = f"{GOOGLE_TRANSLATE_URL}?{urlencode({'key': api_key.strip()})}"
    request = Request(
        endpoint,
        data=request_body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )

    try:
        with opener(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        detail = _redact_api_key(_google_error_detail(exc), api_key)
        suffix = f": {detail}" if detail else ""
        raise TranslationError(f"Google 翻译请求失败（HTTP {exc.code}）{suffix}") from exc
    except URLError as exc:
        reason = _redact_api_key(str(exc.reason), api_key)
        raise TranslationError(f"无法连接 Google 翻译服务：{reason}") from exc
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise TranslationError(f"Google 翻译响应无效：{type(exc).__name__}") from exc

    try:
        translated = payload["data"]["translations"][0]["translatedText"]
    except (KeyError, IndexError, TypeError) as exc:
        raise TranslationError("Google 翻译响应中没有 translatedText") from exc

    result = html.unescape(str(translated)).strip()
    if not result:
        raise TranslationError("Google 翻译返回了空结果")
    return result


def _google_error_detail(exc: HTTPError) -> str:
    """Extract a short API error without echoing the request URL/API key."""
    try:
        payload = json.loads(exc.read().decode("utf-8"))
        message = str(payload.get("error", {}).get("message", "")).strip()
    except (AttributeError, OSError, UnicodeError, json.JSONDecodeError):
        return ""
    return message[:240]


def _redact_api_key(message: str, api_key: str) -> str:
    key = (api_key or "").strip()
    return message.replace(key, "[已隐藏]") if key else message
