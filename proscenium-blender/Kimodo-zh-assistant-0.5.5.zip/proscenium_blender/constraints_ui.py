"""Constraint authoring with native Blender objects.

The MMCP protocol has three constraint primitives. Each one is exposed in the
addon as a Blender object the artist can see and edit in the viewport:

  root_path        →  a Bezier curve named ``Proscenium_RootPath_*`` with
                      a custom prop ``proscenium_is_root_path = True``.
  effector_target  →  an Empty with ``proscenium_target_joint = "<name>"``,
                      location-keyframed across the timeline.
  pose_keyframe    →  derived from the target armature's existing keyframes
                      in its source action; no dedicated object.

This module owns:
  * The operators that create / focus / remove the constraint objects.
  * A scene-walker that returns the lists of root-path curves and effector
    empties active in the current scene.
  * Sampling helpers that turn each Blender object into the MMCP constraint
    dict shape (``{"type": "...", "frames": [...], ...}``).

The actual assembly of the request body lives in ``request_builder.py`` —
this module is purely UI + sampling.
"""

from __future__ import annotations

import math
import re
from typing import Any, Iterable

import bpy
from bpy.props import EnumProperty
from bpy.types import Operator
from mathutils import Matrix, Vector
from mathutils.geometry import interpolate_bezier

from . import constants, coords


# MMCP world (right-handed Y-up) → Blender world (right-handed Z-up). Used
# to conjugate Blender-frame rotation matrices back into MMCP frame when
# sampling pose keyframes for the request.
_MMCP_TO_BLENDER = Matrix((
    (1.0, 0.0,  0.0),
    (0.0, 0.0, -1.0),
    (0.0, 1.0,  0.0),
))


# Bones Kimodo's EndEffector constraint can pin in "generate" (fill_mode)
# mode: the 5 EE chains plus the root. When ``sample_pose_keyframes``
# detects a keyed bone outside this set (spine, neck, arms mid-chain, etc.),
# we switch fill_mode to "rest" so the server pins every joint position via
# FullBodyConstraintSet — otherwise those off-chain keyframes would be
# silently dropped.
_EE_CHAIN_BONES = frozenset({
    "Hips",
    "LeftFoot", "LeftToeBase",
    "RightFoot", "RightToeBase",
    "LeftHand", "LeftHandMiddleEnd",
    "RightHand", "RightHandMiddleEnd",
})


# ---------------------------------------------------------------------------
# Action API compatibility
# ---------------------------------------------------------------------------

def iter_action_fcurves(action):
    """Yield every F-curve in an Action, regardless of Blender version.

    Pre-Blender 4.4: ``action.fcurves`` is a flat collection.
    Blender 4.4+ moved to a layered Action with slots/strips/channelbags;
    the flat ``.fcurves`` attribute was removed in 5.x.
    """
    if action is None:
        return
    flat = getattr(action, "fcurves", None)
    if flat is not None:
        yield from flat
        return
    for layer in getattr(action, "layers", ()):
        for strip in getattr(layer, "strips", ()):
            slots = getattr(action, "slots", ())
            for slot in slots:
                cb = strip.channelbag(slot, ensure=False) if hasattr(strip, "channelbag") else None
                if cb is None:
                    continue
                yield from cb.fcurves


def _iter_fcurve_collections(action):
    """Yield each F-curve container on ``action`` (flat or per-channelbag),
    so callers can mutate (add/remove fcurves) instead of just iterating."""
    flat = getattr(action, "fcurves", None)
    if flat is not None:
        yield flat
        return
    for layer in getattr(action, "layers", ()):
        for strip in getattr(layer, "strips", ()):
            if not hasattr(strip, "channelbag"):
                continue
            for slot in getattr(action, "slots", ()):
                cb = strip.channelbag(slot, ensure=False)
                if cb is not None:
                    yield cb.fcurves


def strip_generated_keyframe_points(action) -> int:
    """Remove ``GENERATED``-typed keyframe points from every F-curve on ``action``.

    Motion bakes tag constraint anchors as ``KEYFRAME`` and dense samples as
    ``GENERATED`` (see ``gltf_to_blender._tag_keyframe_types``). Reject should
    drop only the generated samples so keys added while previewing are kept.
    When any channel has an authored key at a frame, generated samples on
    other channels at that same frame are promoted to ``KEYFRAME`` too — that
    preserves the full-body pose at the authored frame instead of leaving
    unkeyed bones at rest.

    Returns the number of keyframe points removed. F-curves left with no
    keys are removed.
    """
    if action is None:
        return 0

    authored_frames = {
        int(round(kp.co.x))
        for fc in iter_action_fcurves(action)
        for kp in fc.keyframe_points
        if kp.type != 'GENERATED'
    }

    removed = 0
    for fcurves in _iter_fcurve_collections(action):
        for fc in list(fcurves):
            kps = fc.keyframe_points
            for i in range(len(kps) - 1, -1, -1):
                if kps[i].type != 'GENERATED':
                    continue
                if int(round(kps[i].co.x)) in authored_frames:
                    kps[i].type = 'KEYFRAME'
                    continue
                kps.remove(kps[i])
                removed += 1
            fc.update()
            if len(fc.keyframe_points) == 0:
                fcurves.remove(fc)

    return removed


def _ensure_fcurve(action, data_path: str, array_index: int):
    """Get the F-curve at ``(data_path, array_index)`` on ``action``, or
    create one. Returns ``None`` if neither lookup nor creation succeeds.

    Works for both flat (pre-Blender 4.4) and layered (4.4+) actions; on a
    layered action the new curve goes onto the first existing channelbag,
    which matches how the rest of this module reads fcurves back.
    """
    flat = getattr(action, "fcurves", None)
    if flat is not None:
        fc = flat.find(data_path=data_path, index=array_index)
        if fc is not None:
            return fc
        try:
            return flat.new(data_path=data_path, index=array_index)
        except RuntimeError:
            return None

    for layer in getattr(action, "layers", ()):
        for strip in getattr(layer, "strips", ()):
            if not hasattr(strip, "channelbag"):
                continue
            for slot in getattr(action, "slots", ()):
                cb = strip.channelbag(slot, ensure=False)
                if cb is None:
                    continue
                fc = cb.fcurves.find(data_path=data_path, index=array_index)
                if fc is not None:
                    return fc
                try:
                    return cb.fcurves.new(data_path=data_path, index=array_index)
                except RuntimeError:
                    continue
    return None


def _copy_keyframe_point(src_kp, dest_fc) -> None:
    """Insert or replace one key on ``dest_fc`` matching ``src_kp``'s frame.

    ``keyframe_points.insert`` updates an existing key at the same frame in
    place, so no explicit removal is needed.
    """
    dst = dest_fc.keyframe_points.insert(
        float(src_kp.co.x),
        float(src_kp.co.y),
    )
    dst.handle_left      = src_kp.handle_left
    dst.handle_right     = src_kp.handle_right
    dst.handle_left_type = src_kp.handle_left_type
    dst.handle_right_type = src_kp.handle_right_type
    dst.interpolation    = src_kp.interpolation
    dst.easing           = src_kp.easing
    dst.type             = src_kp.type


def merge_preview_keyframes_into_source(source_action, preview_action) -> int:
    """Copy keyframe points from ``preview_action`` onto matching F-curves
    on ``source_action``. Existing keys at the same frame are replaced.

    Used after ``strip_generated_keyframe_points`` on the preview: channels
    that only had generated samples disappear from the preview, but
    ``source_action`` keeps the pre-generation curves so the rig doesn't
    fall back to rest pose on those bones.

    Returns the number of keyframe points written.
    """
    if source_action is None or preview_action is None:
        return 0

    merged = 0
    for prev_fc in iter_action_fcurves(preview_action):
        dest_fc = _ensure_fcurve(source_action, prev_fc.data_path, prev_fc.array_index)
        if dest_fc is None:
            continue
        for src_kp in sorted(prev_fc.keyframe_points, key=lambda kp: kp.co.x):
            if src_kp.type == 'GENERATED':
                continue
            _copy_keyframe_point(src_kp, dest_fc)
            merged += 1
        dest_fc.update()

    return merged


# ---------------------------------------------------------------------------
# Scene walker
# ---------------------------------------------------------------------------

def walk_scene_constraints(scene: bpy.types.Scene) -> dict[str, list[bpy.types.Object]]:
    """Find every Blender object in the scene that the addon should treat as
    an MMCP constraint. Returns a dict keyed by primitive type."""
    root_paths: list[bpy.types.Object] = []
    effectors:  list[bpy.types.Object] = []
    for obj in scene.objects:
        if obj.get(constants.PROP_IS_ROOT_PATH) and obj.type == 'CURVE':
            root_paths.append(obj)
        elif obj.get(constants.PROP_TARGET_JOINT) and obj.type == 'EMPTY':
            effectors.append(obj)
    return {"root_paths": root_paths, "effector_targets": effectors}


# ---------------------------------------------------------------------------
# Operators — Add / Remove / Focus
# ---------------------------------------------------------------------------

class PROSCENIUM_OT_add_root_path(Operator):
    bl_idname = "proscenium.add_root_path"
    bl_label = "Add Root Path"
    bl_description = (
        "Create a Bezier curve on the floor plane that the character will follow. "
        "Sample density and 'follow direction' (heading) are editable on the curve "
        "object's properties"
    )
    # Note: no ``UNDO`` flag. With UNDO enabled on a slotted-action scene,
    # Blender's undo snapshot diff was observed to drop unreferenced fcurves
    # — including the root bone's vertical-axis keyframes — after the op
    # completed. The bake itself never writes that axis, so this was purely
    # an undo-system artifact; dropping UNDO keeps the channel intact.
    bl_options = {'REGISTER'}

    match_direction: bpy.props.BoolProperty(
        name="Follow Direction",
        description="Derive heading_radians from the curve tangent so the character faces along the path",
        default=True,
    )
    sample_density: bpy.props.IntProperty(
        name="Sample Every N Frames",
        description="One root_path constraint frame per N timeline frames",
        default=10, min=1, max=60,
    )

    def execute(self, context):
        scene = context.scene

        # Seed the curve from root-bone location keyframes when available —
        # one spline control point per existing keyframe, preserving the
        # user's authored timing exactly. Fall back to a default 2 m line
        # (densified to a handful of handles) only when the armature has no
        # root-location keys at all.
        keyframe_points = _root_keyframe_points(scene)
        if keyframe_points:
            control_points = keyframe_points
        else:
            control_points = _densify_points(
                _default_root_points(),
                min_count=max(4, constants.ROOT_PATH_CONTROL_POINTS),
            )

        # 2D curve: Blender stores only the XY plane (floor). That matches
        # MMCP's root_path primitive, which is a smooth_root xz trajectory —
        # the protocol has no notion of vertical root motion.
        curve_data = bpy.data.curves.new("Proscenium_RootPath", type='CURVE')
        curve_data.dimensions = '2D'
        curve_data.resolution_u = 12
        spline = curve_data.splines.new('BEZIER')
        spline.bezier_points.add(len(control_points) - 1)
        for pt, pos in zip(spline.bezier_points, control_points):
            pt.co                = pos
            pt.handle_left_type  = 'AUTO'
            pt.handle_right_type = 'AUTO'

        existing = sum(1 for o in scene.objects if o.get(constants.PROP_IS_ROOT_PATH))
        obj_name = f"Proscenium_RootPath_{existing + 1:02d}"
        obj = bpy.data.objects.new(obj_name, curve_data)
        obj[constants.PROP_IS_ROOT_PATH]    = True
        obj[constants.PROP_MATCH_DIRECTION] = self.match_direction
        obj[constants.PROP_SAMPLE_DENSITY]  = self.sample_density
        scene.collection.objects.link(obj)

        _select_only(context, obj)
        self.report({'INFO'}, f"Added {obj_name} ({len(control_points)} control points)")
        return {'FINISHED'}


def _default_root_points() -> list[Vector]:
    """Fallback seed: a 2 m line along +X on the floor."""
    n = max(2, constants.ROOT_PATH_CONTROL_POINTS)
    return [Vector((i / (n - 1) * 2.0, 0.0, 0.0)) for i in range(n)]


def _densify_points(points: list[Vector], *, min_count: int) -> list[Vector]:
    """Return ``points`` augmented with linearly-interpolated midpoints so
    the total is at least ``min_count``. Preserves every original point —
    midpoints get inserted into the currently-longest segment, one at a
    time, until the count is reached.
    """
    pts = list(points)
    while len(pts) < min_count and len(pts) >= 2:
        longest_i, longest_len = 0, -1.0
        for i in range(len(pts) - 1):
            d = (pts[i + 1] - pts[i]).length
            if d > longest_len:
                longest_len = d
                longest_i = i
        mid = (pts[longest_i] + pts[longest_i + 1]) * 0.5
        pts.insert(longest_i + 1, mid)
    return pts


def _root_keyframe_points(scene: bpy.types.Scene) -> list[Vector]:
    """World xz of the root bone at each root-location keyframe, projected
    onto the ground plane (z=0). Returns an empty list if the target armature
    has no root location keys in the scene range — the operator then falls
    back to a default line.
    """
    settings = scene.proscenium
    arm = settings.target_armature
    if arm is None or arm.type != 'ARMATURE':
        return []
    action = arm.animation_data.action if arm.animation_data else None
    if action is None:
        return []

    root_pb = next((pb for pb in arm.pose.bones if pb.parent is None), None)
    if root_pb is None:
        return []

    frame_range = (int(scene.frame_start), int(scene.frame_end))
    times: set[int] = set()
    for fc in iter_action_fcurves(action):
        if "location" not in fc.data_path:
            continue
        if _bone_name_from_data_path(fc.data_path) != root_pb.name:
            continue
        for kp in fc.keyframe_points:
            f = int(round(kp.co.x))
            if frame_range[0] <= f <= frame_range[1]:
                times.add(f)
    if len(times) < 2:
        return []

    saved = scene.frame_current
    try:
        points: list[Vector] = []
        for f in sorted(times):
            scene.frame_set(f)
            # Force depsgraph re-evaluation — ``scene.frame_set`` alone
            # doesn't always propagate through drivers / constraint stacks,
            # so the pose-bone matrix would otherwise read stale values.
            bpy.context.view_layer.update()
            world = (arm.matrix_world @ root_pb.matrix).translation
            points.append(Vector((world.x, world.y, 0.0)))
        return points
    finally:
        scene.frame_set(saved)


def _joint_items_callback(self, context):
    """End-effector joints from the target armature, for the pin popup.

    Restricted to the four canonical limb tips
    (``constants.END_EFFECTOR_JOINTS``); pinning interior chain joints
    over-constrains the IK solver. Joints absent from the armature are
    filtered out so the popup only offers what can actually be pinned.
    """
    settings = context.scene.proscenium
    arm = settings.target_armature
    if arm is None or arm.type != 'ARMATURE':
        return [("", "(set a target armature first)", "")]
    pose_bones = {pb.name for pb in arm.pose.bones}
    items = [
        (name, name, "")
        for name in constants.END_EFFECTOR_JOINTS
        if name in pose_bones
    ]
    return items or [("", "(armature has no canonical end-effector joints)", "")]


class PROSCENIUM_OT_add_effector_target(Operator):
    bl_idname = "proscenium.add_effector_target"
    bl_label = "Add Effector Pin"
    bl_description = (
        "Pin a named joint to a moving Blender Empty. Each location keyframe "
        "on the empty becomes one effector_target constraint frame"
    )
    bl_options = {'REGISTER', 'UNDO'}

    joint: EnumProperty(
        name="Joint",
        items=_joint_items_callback,
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=240)

    def draw(self, context):
        col = self.layout.column(align=True)
        col.prop(self, "joint")

    def execute(self, context):
        if not self.joint:
            self.report({'ERROR'}, "Pick a joint")
            return {'CANCELLED'}

        settings = context.scene.proscenium
        arm = settings.target_armature
        if arm is None:
            self.report({'ERROR'}, "Set a target armature first")
            return {'CANCELLED'}

        bone = arm.pose.bones.get(self.joint)
        # bone.head is in armature-local space. Empties have no parent, so
        # empty.location is world-space — transform through the armature's
        # world matrix to keep the pin at the bone's actual viewport position
        # (otherwise a translated/rotated armature puts the empty at the wrong
        # spot, which looks like a "rotation" offset).
        if bone is not None:
            start_pos = arm.matrix_world @ bone.head
        else:
            start_pos = Vector((0.0, 1.0, 0.0))

        empty = bpy.data.objects.new(f"Proscenium_{self.joint}_Target", None)
        empty.empty_display_type = 'SPHERE'
        empty.empty_display_size = constants.EFFECTOR_EMPTY_SIZE
        empty.location           = start_pos

        empty[constants.PROP_TARGET_JOINT] = self.joint
        # Drop a colour swatch on Object so the user can spot it in viewport.
        if self.joint in constants.EFFECTOR_COLORS:
            empty.color = constants.EFFECTOR_COLORS[self.joint]
            empty.show_name = True

        context.scene.collection.objects.link(empty)
        # Seed with one keyframe at the current frame so it's a valid constraint.
        empty.keyframe_insert(data_path="location", frame=context.scene.frame_current)

        _select_only(context, empty)
        self.report({'INFO'}, f"Added effector pin for {self.joint}")
        return {'FINISHED'}


class PROSCENIUM_OT_remove_constraint_object(Operator):
    bl_idname = "proscenium.remove_constraint_object"
    bl_label = "Remove Constraint Object"
    bl_description = "Delete the named constraint object from the scene"
    bl_options = {'REGISTER', 'UNDO'}

    name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.name)
        if obj is None:
            return {'CANCELLED'}
        bpy.data.objects.remove(obj, do_unlink=True)
        for area in context.screen.areas:
            area.tag_redraw()
        return {'FINISHED'}


class PROSCENIUM_OT_focus_constraint_object(Operator):
    bl_idname = "proscenium.focus_constraint_object"
    bl_label = "Focus Constraint Object"
    bl_description = "Select and view-frame the named constraint object"
    bl_options = {'REGISTER', 'UNDO'}

    name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.name)
        if obj is None:
            return {'CANCELLED'}
        _select_only(context, obj)
        return {'FINISHED'}


def _select_only(context, obj: bpy.types.Object) -> None:
    for o in context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj


# ---------------------------------------------------------------------------
# Sampling — Blender object → MMCP constraint dict
# ---------------------------------------------------------------------------

def _mmcp_heading_from_xz_tangent(tx: float, tz: float) -> float:
    """Yaw (radians) about MMCP +Y so the horizontal forward axis aligns with
    tangent ``(tx, 0, tz)`` in MMCP space — ``atan2(tx, tz)`` is the angle in
    the XZ plane from +Z toward +X (right-handed about +Y).
    """
    return math.atan2(tx, tz)


def _root_path_world_polyline(curve_obj: bpy.types.Object) -> list[Vector] | None:
    """World-space polyline sampled from a root-path curve, or ``None`` if
    the spline cannot yield a tangent (missing data or fewer than two
    distinct samples).
    """
    spline = curve_obj.data.splines[0] if curve_obj.data.splines else None
    if spline is None or len(spline.bezier_points) < 2:
        return None
    local_polyline = _bezier_to_polyline(spline, segments_per_segment=12)
    if len(local_polyline) < 2:
        return None
    mw = curve_obj.matrix_world
    return [mw @ p for p in local_polyline]


def root_path_heading_at_start(curve_obj: bpy.types.Object) -> float | None:
    """MMCP ``heading_radians`` at the start of ``curve_obj``, or ``None`` if
    direction matching is off or the curve has no usable tangent.

    Uses the same tangent → heading mapping as :func:`sample_root_path`.
    """
    if not curve_obj.get(constants.PROP_MATCH_DIRECTION):
        return None
    polyline = _root_path_world_polyline(curve_obj)
    if polyline is None:
        return None
    tangent = _tangent_at(polyline, 0)
    tx, _, tz = coords.blender_pos_to_mmcp(tangent)
    return _mmcp_heading_from_xz_tangent(tx, tz)


def sample_root_path(
    curve_obj: bpy.types.Object,
    *,
    total_frames: int,
) -> dict[str, Any] | None:
    """Sample a Bezier curve into a `root_path` constraint dict.

    The curve is treated as a static spatial trajectory; the character walks
    along it over the request's timeline. We sample at evenly-spaced frame
    indices in the request frame range. Returns ``None`` if the curve has no
    spline data (corrupt) or fewer than 2 points.
    """
    if total_frames < 1:
        return None
    polyline = _root_path_world_polyline(curve_obj)
    if polyline is None:
        return None

    density = max(1, int(curve_obj.get(constants.PROP_SAMPLE_DENSITY, 10)))
    frames = list(range(0, total_frames, density))
    if frames[-1] != total_frames - 1:
        frames.append(total_frames - 1)

    positions_xz: list[tuple[float, float]] = []
    headings:     list[float] = []

    last_idx = len(polyline) - 1
    denom = max(1, total_frames - 1)
    for f in frames:
        t = f / denom                          # 0..1 along the curve
        idx = max(0, min(last_idx, int(round(t * last_idx))))
        world = polyline[idx]
        x_mmcp, _, z_mmcp = coords.blender_pos_to_mmcp(world)
        positions_xz.append((x_mmcp, z_mmcp))

        if curve_obj.get(constants.PROP_MATCH_DIRECTION):
            tangent = _tangent_at(polyline, idx)
            tx, _, tz = coords.blender_pos_to_mmcp(tangent)
            headings.append(_mmcp_heading_from_xz_tangent(tx, tz))

    constraint: dict[str, Any] = {
        "type": "root_path",
        "frames": frames,
        "positions_xz": [list(p) for p in positions_xz],
    }
    if headings:
        constraint["heading_radians"] = headings
    return constraint


def sample_effector_target(
    empty_obj: bpy.types.Object,
    *,
    frame_range: tuple[int, int],
    total_frames: int,
) -> dict[str, Any] | None:
    """Convert an effector-target empty into an `effector_target` constraint.

    Walks the empty's location fcurve keyframes within ``frame_range`` and
    emits one constraint frame per keyframe. Frame indices are translated
    from Blender frames to the request's timeline (0..total_frames-1).
    Returns ``None`` if the empty has no keyframes in range.
    """
    joint = (empty_obj.get(constants.PROP_TARGET_JOINT) or "").strip()
    if not joint:
        return None

    frames_in_range: set[int] = set()
    if empty_obj.animation_data and empty_obj.animation_data.action:
        for fc in iter_action_fcurves(empty_obj.animation_data.action):
            if fc.data_path != "location":
                continue
            for kp in fc.keyframe_points:
                f = int(round(kp.co.x))
                if frame_range[0] <= f <= frame_range[1]:
                    frames_in_range.add(f)

    if not frames_in_range:
        # No keyframes in range — fall back to the current static location at
        # a single frame (frame_range start) so the user gets a usable pin
        # without having to keyframe.
        frames_in_range.add(frame_range[0])

    sorted_frames = sorted(frames_in_range)
    positions: list[list[float]] = []

    scene = bpy.context.scene
    original = scene.frame_current
    try:
        for f in sorted_frames:
            scene.frame_set(f)
            # Force depsgraph re-evaluation — ``scene.frame_set`` alone
            # doesn't always propagate through drivers / parent chains /
            # constraint stacks, so ``matrix_world`` would otherwise read
            # the *previous* frame's translation. Same fix is applied in
            # ``sample_pose_keyframes``; keep them in sync.
            bpy.context.view_layer.update()
            world = empty_obj.matrix_world.translation
            mx, my, mz = coords.blender_pos_to_mmcp(world)
            positions.append([mx, my, mz])
    finally:
        scene.frame_set(original)

    return {
        "type": "effector_target",
        "joint": joint,
        "frames": [_to_timeline_frame(f, frame_range) for f in sorted_frames],
        "positions": positions,
    }


def _evaluated_local_basis(pb: bpy.types.PoseBone) -> 'Matrix':
    """The bone-local matrix_basis equivalent computed from the *evaluated*
    pose-bone matrix, so constraint-driven bones (control-rig setups) report
    a non-identity basis even though they were never directly keyed.

    For a freely-keyed bone this returns exactly ``pb.matrix_basis``; for a
    bone driven by a Copy*/IK constraint it returns the basis that, applied
    against the bone's rest, would reproduce ``pb.matrix``.
    """
    if pb.parent is None:
        return pb.bone.matrix_local.inverted() @ pb.matrix
    parent_offset = pb.bone.matrix_local.inverted() @ pb.parent.bone.matrix_local
    return parent_offset @ pb.parent.matrix.inverted() @ pb.matrix


def sample_pose_keyframes(
    armature_obj: bpy.types.Object,
    *,
    source_action: bpy.types.Action,
    frame_range: tuple[int, int],
) -> list[dict[str, Any]]:
    """Walk ``source_action`` for frames with rotation keyframes and emit one
    pose_keyframe constraint per such frame, capturing every pose bone's
    current rotation at that frame.

    Control-rig aware: when the armature is detected as a control rig
    (deform bones driven by Copy*/IK constraints), keyframes are collected
    from any bone (the user typically keys *control* bones), and rotations
    are sampled on the *deform* bones via their evaluated pose. That way
    posing a Mixamo/Rigify/ARP control rig produces the same MMCP request
    as if the user had keyed the deform skeleton directly.

    The armature's current action is temporarily set to ``source_action``
    so the evaluation matches what the user authored.
    """
    if armature_obj is None or source_action is None:
        return []

    # Lazy-import to avoid request_builder ↔ constraints_ui circular at
    # module load — both modules are pulled into __init__'s register flow.
    from . import request_builder

    root_pb = next(
        (pb for pb in armature_obj.pose.bones if pb.parent is None),
        None,
    )

    # Use the same filtered deform set as :func:`armature_to_skeleton` —
    # face / tweak-half bones we strip out of the request must not appear
    # in pose_keyframe ``joint_rotations`` either, or the server-side
    # validator rejects the constraint as referencing unknown joints.
    deform_bones = request_builder.emitted_deform_bones(armature_obj)
    is_control_rig = request_builder.is_control_rig(armature_obj)

    # pose_keyframes describe a BODY POSE. If no bone has rotation keyframes,
    # there's no pose to pin — just root motion — and the root_path
    # constraint (from the path curve) handles that channel. A rig whose
    # only keyframes are root-bone location keys (the path_follow sync case)
    # therefore emits zero pose_keyframes; the root location flows through
    # root_path instead.
    interesting_frames: set[int] = set()
    keyed_bones: set[str] = set()
    for fc in iter_action_fcurves(source_action):
        bone_name = _bone_name_from_data_path(fc.data_path)
        if bone_name is None:
            continue
        if "rotation" not in fc.data_path:
            continue
        keyed_bones.add(bone_name)
        for kp in fc.keyframe_points:
            f = int(round(kp.co.x))
            if frame_range[0] <= f <= frame_range[1]:
                interesting_frames.add(f)
    if not interesting_frames or not keyed_bones:
        return []

    # In control-rig mode the user keys controls; the deform bones (what
    # we serialize) get their pose from the constraint stack. Sample those.
    # In direct mode the user keys the deform bones themselves; sample the
    # bones that actually have rotation keyframes.
    sample_bone_names = deform_bones if is_control_rig else keyed_bones

    # Temporarily attach the source action so frame evaluation hits the
    # user's authored poses.
    if armature_obj.animation_data is None:
        armature_obj.animation_data_create()
    saved_action = armature_obj.animation_data.action
    armature_obj.animation_data.action = source_action

    scene = bpy.context.scene
    original = scene.frame_current

    # Per-bone rotation delta, converted to MMCP world frame in three steps:
    #   1. ``ML @ R_basis @ ML.T``   — bone-local-rest → armature-local
    #   2. ``mw_rot @ _ @ mw_rot.T`` — armature-local → Blender world
    #                                  (no-op when armature is at identity;
    #                                   required for rigs like Mixamo that
    #                                   carry a 90° + 0.01 matrix_world).
    #   3. ``S_inv @ _ @ S``         — Blender Z-up → MMCP Y-up
    # The inverse of this chain lives in ``gltf_to_blender.py`` on the bake
    # path and must stay in sync.
    S        = _MMCP_TO_BLENDER
    S_inv    = S.transposed()
    mw_rot   = armature_obj.matrix_world.to_quaternion().to_matrix()
    mw_rot_t = mw_rot.transposed()

    # Heuristic: if the user keyed bones that live outside Kimodo's
    # end-effector chains (spine, neck, shoulders, arms, etc.), they clearly
    # want those poses pinned. Control-rig setups always go through full
    # body — there's no easy mapping from keyed control bones to canonical
    # EE groups, and the user's intent is to author the whole pose.
    fill_mode = (
        "rest"
        if (is_control_rig or any(b not in _EE_CHAIN_BONES for b in keyed_bones))
        else "generate"
    )

    constraints: list[dict[str, Any]] = []
    sampled_pbs = [pb for pb in armature_obj.pose.bones if pb.name in sample_bone_names]
    try:
        for f in sorted(interesting_frames):
            scene.frame_set(f)
            # Force depsgraph re-evaluation — ``scene.frame_set`` alone
            # doesn't always propagate through drivers / constraint stacks /
            # NLA, and the evaluated matrices then read stale values from
            # the previous frame.
            bpy.context.view_layer.update()
            joint_rotations: dict[str, list[float]] = {}
            for pb in sampled_pbs:
                R_basis = _evaluated_local_basis(pb).to_3x3()
                ML      = pb.bone.matrix_local.to_3x3()
                R_blender_arm = ML @ R_basis @ ML.transposed()
                R_blender_world = mw_rot @ R_blender_arm @ mw_rot_t
                R_mmcp = S_inv @ R_blender_world @ S
                w, x, y, z = R_mmcp.to_quaternion()
                joint_rotations[pb.name] = [x, y, z, w]

            if not joint_rotations:
                continue

            entry: dict[str, Any] = {
                "type":            "pose_keyframe",
                "frame":           _to_timeline_frame(f, frame_range),
                "joint_rotations": joint_rotations,
                "fill_mode":       fill_mode,
            }
            # Always send the root's **world**-space position so the server
            # has per-frame root motion to retarget. Without this, every
            # pose_keyframe defaults to the canonical standing root on the
            # server and the generated character's root never moves —
            # observable as "body animates but root stays nailed at MMCP
            # origin." Uses the full ``armature.matrix_world @ pose_bone.matrix``
            # chain so this captures both:
            #   * the armature object's world transform (user drags the rig
            #     around in object mode),
            #   * the root bone's pose matrix (user keyframes location in
            #     pose mode).
            #
            # When the rig is a control rig, the *deform* root bone is what
            # the server will see — pull its evaluated head world position,
            # not the armature's outer root pose bone.
            sample_root = root_pb
            if is_control_rig and root_pb is not None and root_pb.name not in deform_bones:
                # Find the topmost deform bone; that's the deform skeleton's root.
                for pb in armature_obj.pose.bones:
                    if pb.name in deform_bones:
                        cur = pb
                        while cur.parent is not None and cur.parent.name in deform_bones:
                            cur = cur.parent
                        sample_root = cur
                        break
            if sample_root is not None:
                root_world = (armature_obj.matrix_world @ sample_root.matrix).translation
                root_mmcp = coords.blender_pos_to_mmcp(root_world)
                entry["root_position"] = list(root_mmcp)
            constraints.append(entry)
    finally:
        scene.frame_set(original)
        if saved_action is not None:
            armature_obj.animation_data.action = saved_action

    return constraints


def sample_pose_at_frame(
    armature_obj: bpy.types.Object,
    *,
    source_action: bpy.types.Action,
    sample_frame: int,
    request_frame: int,
    fill_mode: str = "rest",
    bone_names: set[str] | None = None,
) -> dict[str, Any] | None:
    """Sample one ``pose_keyframe`` constraint from any action at one frame.

    Unlike :func:`sample_pose_keyframes`, this does **not** consult the
    feedback-loop guard that refuses to read from Proscenium-generated
    actions. The caller decides which action to read — used by single-block
    regen to grab boundary observations from the preview bake, which is
    exactly the case ``sample_pose_keyframes`` is built to refuse.

    ``sample_frame`` is the Blender scene frame to evaluate the pose at;
    ``request_frame`` is the timeline-relative index that lands in the
    constraint dict's ``frame`` field. Default ``fill_mode="rest"`` so
    boundary observations pin the full body — the contract is "the body is
    exactly here at this frame", not "freely interpolate around these EE
    positions".

    When ``bone_names`` is provided, ``joint_rotations`` is restricted to
    those bones (intersected with the rig's natural sample set — deform
    bones on a control rig, all pose bones otherwise). Used by per-block
    regen to pin only the bones the user actually edited, leaving the rest
    of the body free for the model to interpolate. ``None`` samples the
    full pose (matching the boundary-observation use case).
    """
    if armature_obj is None or source_action is None:
        return None

    from . import request_builder  # noqa: PLC0415 — module-load circular

    deform_bones = request_builder.detect_deform_bones(armature_obj)
    is_control_rig = request_builder.is_control_rig(armature_obj)

    sample_bone_names = (
        deform_bones
        if is_control_rig
        else {pb.name for pb in armature_obj.pose.bones}
    )
    if bone_names is not None:
        sample_bone_names = sample_bone_names & bone_names
    if not sample_bone_names:
        return None

    if armature_obj.animation_data is None:
        armature_obj.animation_data_create()
    saved_action = armature_obj.animation_data.action
    armature_obj.animation_data.action = source_action

    scene = bpy.context.scene
    original = scene.frame_current

    S = _MMCP_TO_BLENDER
    S_inv = S.transposed()
    mw_rot = armature_obj.matrix_world.to_quaternion().to_matrix()
    mw_rot_t = mw_rot.transposed()

    root_pb = next(
        (pb for pb in armature_obj.pose.bones if pb.parent is None),
        None,
    )
    sample_root = root_pb
    if is_control_rig and root_pb is not None and root_pb.name not in deform_bones:
        for pb in armature_obj.pose.bones:
            if pb.name in deform_bones:
                cur = pb
                while cur.parent is not None and cur.parent.name in deform_bones:
                    cur = cur.parent
                sample_root = cur
                break

    try:
        scene.frame_set(sample_frame)
        bpy.context.view_layer.update()

        joint_rotations: dict[str, list[float]] = {}
        for pb in armature_obj.pose.bones:
            if pb.name not in sample_bone_names:
                continue
            R_basis = _evaluated_local_basis(pb).to_3x3()
            ML = pb.bone.matrix_local.to_3x3()
            R_blender_arm = ML @ R_basis @ ML.transposed()
            R_blender_world = mw_rot @ R_blender_arm @ mw_rot_t
            R_mmcp = S_inv @ R_blender_world @ S
            w, x, y, z = R_mmcp.to_quaternion()
            joint_rotations[pb.name] = [x, y, z, w]

        if not joint_rotations:
            return None

        entry: dict[str, Any] = {
            "type":            "pose_keyframe",
            "frame":           int(request_frame),
            "joint_rotations": joint_rotations,
            "fill_mode":       fill_mode,
        }
        if sample_root is not None:
            root_world = (armature_obj.matrix_world @ sample_root.matrix).translation
            root_mmcp = coords.blender_pos_to_mmcp(root_world)
            entry["root_position"] = list(root_mmcp)
        return entry
    finally:
        scene.frame_set(original)
        if saved_action is not None:
            armature_obj.animation_data.action = saved_action


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _bezier_to_polyline(spline, *, segments_per_segment: int = 12) -> list[Vector]:
    """Sample a single Bezier spline into a flat list of world-space points."""
    pts = spline.bezier_points
    polyline: list[Vector] = []
    for i in range(len(pts) - 1):
        a, b = pts[i], pts[i + 1]
        seg = interpolate_bezier(
            a.co, a.handle_right, b.handle_left, b.co, segments_per_segment + 1
        )
        if i > 0:
            seg = seg[1:]   # avoid duplicating segment endpoints
        polyline.extend(seg)
    return polyline


def _tangent_at(polyline: list[Vector], idx: int) -> Vector:
    n = len(polyline)
    if n < 2:
        return Vector((0.0, 1.0, 0.0))
    if idx <= 0:
        v = polyline[1] - polyline[0]
    elif idx >= n - 1:
        v = polyline[-1] - polyline[-2]
    else:
        v = polyline[idx + 1] - polyline[idx - 1]
    return v.normalized() if v.length else Vector((0.0, 1.0, 0.0))


def _to_timeline_frame(blender_frame: int, frame_range: tuple[int, int]) -> int:
    return max(0, blender_frame - frame_range[0])


_BONE_DATA_PATH_RE = re.compile(r'pose\.bones\["([^"]+)"\]')


def _bone_name_from_data_path(data_path: str) -> str | None:
    """Return the bone name referenced by a pose-bone fcurve data path.

    Typical shapes: ``pose.bones["Hips"].rotation_quaternion``,
    ``pose.bones["LeftArm"].rotation_euler``.
    """
    m = _BONE_DATA_PATH_RE.search(data_path)
    return m.group(1) if m else None


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

_classes = (
    PROSCENIUM_OT_add_root_path,
    PROSCENIUM_OT_add_effector_target,
    PROSCENIUM_OT_remove_constraint_object,
    PROSCENIUM_OT_focus_constraint_object,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
